package com.entertainment.controller;

import com.entertainment.model.Post;
import com.entertainment.model.Users;
import com.entertainment.repository.PostRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jakarta.servlet.http.HttpSession;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.Objects;

@Controller
public class PostController {

    @Autowired
    private PostRepository postRepository;

    // ✅ Page: Add New Post
    @GetMapping("/addpost")
    public String openAddPostPage(HttpSession session, Model model) {
        Users user = (Users) session.getAttribute("loggedUser");
        if (user == null) {
            return "redirect:/login";
        }

        model.addAttribute("username", user.getUsername());
        return "addpost";
    }

    // ✅ Save new post to DB
    @PostMapping("/savepost")
    public String savePost(
            @RequestParam("media") MultipartFile media,
            @RequestParam("caption") String caption,
            @RequestParam("location") String location,
            HttpSession session,
            RedirectAttributes redirectAttributes) {

        Users user = (Users) session.getAttribute("loggedUser");
        if (user == null) {
            return "redirect:/login";
        }

        try {
            String username = user.getUsername();
            String uploadDir = "C:/SpringUploads/";
            Files.createDirectories(Paths.get(uploadDir));

            // ✅ Save image
            String mediaPath = null;
            if (media != null && !media.isEmpty()) {
                String mediaFilename = System.currentTimeMillis() + "_" + Objects.requireNonNull(media.getOriginalFilename());
                mediaPath = uploadDir + mediaFilename;
                media.transferTo(new File(mediaPath));
            } else {
                redirectAttributes.addFlashAttribute("errorMessage", "❌ Please select an image before posting!");
                return "redirect:/addpost";
            }

            // ✅ Save post
            Post post = new Post();
            post.setAuthor(username);
            post.setCaption(caption);
            post.setLocation(location);
            post.setMediaPath(mediaPath);
            postRepository.save(post);

            redirectAttributes.addFlashAttribute("successMessage", "✅ Post shared successfully!");
            return "redirect:/home";
        } catch (IOException e) {
            redirectAttributes.addFlashAttribute("errorMessage", "❌ Upload failed: " + e.getMessage());
            return "redirect:/addpost";
        }
    }

    // ✅ Homepage: Show all posts (newest first)
    @GetMapping("/home")
    public String home(Model model) {
        List<Post> posts = postRepository.findAllByOrderByIdDesc();
        model.addAttribute("posts", posts);
        return "home";
    }
}
