package com.entertainment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EntertainmentPortal01Application {

	public static void main(String[] args) {
		SpringApplication.run(EntertainmentPortal01Application.class, args);
	}

}
