package com.entertainment.controller;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.entertainment.model.Users;
import com.entertainment.repository.PostRepository;
import com.entertainment.repository.UsersRepository;

import jakarta.servlet.http.HttpSession;

@Controller
public class ProfileController {

    @Autowired
    private PostRepository postRepository;

    @Autowired
    private UsersRepository usersRepository;

    // 📄 Show profile page
    @GetMapping("/profile")
    public ModelAndView showProfile(HttpSession session) {
        ModelAndView mv = new ModelAndView("profile");
        Users user = (Users) session.getAttribute("loggedUser");

        if (user == null) {
            mv.setViewName("redirect:/Entertainment"); // Redirect if not logged in
            return mv;
        }

        mv.addObject("user", user);
        mv.addObject("posts", postRepository.findAllByOrderByIdDesc()); // Or filter by user if available
        return mv;
    }

    // ✏️ Update bio
    @PostMapping("/updateBio")
    public String updateBio(@RequestParam("bio") String bio, HttpSession session) {
        Users user = (Users) session.getAttribute("loggedUser");

        if (user == null) {
            return "redirect:/Entertainment";
        }

        user.setBio(bio);
        usersRepository.save(user);
        session.setAttribute("loggedUser", user); // refresh session
        return "redirect:/profile";
    }

    // 🖼️ Update profile picture
    @PostMapping("/updateProfilePic")
    public String updateProfilePic(@RequestParam("profilePic") MultipartFile file, HttpSession session) {
        Users user = (Users) session.getAttribute("loggedUser");

        if (user == null) {
            return "redirect:/Entertainment";
        }

        if (!file.isEmpty()) {
            try {
                String uploadDir = "uploads/profilePics/";
                File dir = new File(uploadDir);
                if (!dir.exists()) dir.mkdirs();

                String fileName = "user_" + user.getId() + "_" + file.getOriginalFilename();
                File saveFile = new File(uploadDir + fileName);
                file.transferTo(saveFile);

                user.setProfilePic("/" + uploadDir + fileName);
                usersRepository.save(user);
                session.setAttribute("loggedUser", user);

            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return "redirect:/profile";
    }
    
    
    @PostMapping("/uploadProfilePic")
    public String uploadProfilePic(@RequestParam("profilePic") MultipartFile file, HttpSession session) throws IOException {
        Users user = (Users) session.getAttribute("loggedUser");
        if (user == null) return "redirect:/login";

        if (!file.isEmpty()) {
            String uploadDir = "uploads/";
            String fileName = "profile_" + user.getId() + ".jpg";
            Path uploadPath = Paths.get(uploadDir);
            if (!Files.exists(uploadPath)) Files.createDirectories(uploadPath);

            Files.copy(file.getInputStream(), uploadPath.resolve(fileName), StandardCopyOption.REPLACE_EXISTING);
            user.setProfilePic(uploadDir + fileName);
            usersRepository.save(user);
            session.setAttribute("loggedUser", user);
        }

        return "redirect:/profile";
    }

    
}
