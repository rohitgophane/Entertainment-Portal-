package com.entertainment.model;

public enum MediaType {
    NONE, IMAGE, VIDEO, AUDIO
}
