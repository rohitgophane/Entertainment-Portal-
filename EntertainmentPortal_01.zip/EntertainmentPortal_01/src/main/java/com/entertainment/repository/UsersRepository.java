package com.entertainment.repository;

import org.springframework.data.jpa.repository.JpaRepository;
	
import com.entertainment.model.Users;

public interface UsersRepository extends JpaRepository<Users, Integer> {
	
	
	  boolean existsByUsername(String username);  // check username
	    boolean existsByEmail(String email);        // check email
	    Users findByUsernameOrEmail(String username, String email);  // login by username or email
	

}
