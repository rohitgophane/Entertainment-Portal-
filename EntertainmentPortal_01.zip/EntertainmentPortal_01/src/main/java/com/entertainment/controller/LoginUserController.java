package com.entertainment.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.entertainment.model.Users;
import com.entertainment.repository.UsersRepository;

import jakarta.servlet.http.HttpSession;

@Controller
public class LoginUserController {

    @Autowired
    private UsersRepository usersRepository;

    // ✅ Default mapping (Login Page)
    @RequestMapping("/Entertainment")
    public String home() {
        return "login"; // /WEB-INF/views/login.jsp
    }

    // ✅ Signup Page
    @RequestMapping("/signup")
    public String signupPage() {
        return "signup";
    }

    // ✅ Save New User
    @RequestMapping("/saveUser")
    public ModelAndView saveUser(@RequestParam String username,
                                 @RequestParam String email,
                                 @RequestParam String mobile,
                                 @RequestParam String password,
                                 @RequestParam String confirmPassword) {

        ModelAndView mv = new ModelAndView("signup");

        if (!password.equals(confirmPassword)) {
            mv.addObject("error", "Passwords do not match!");
            return mv;
        }

        if (usersRepository.existsByUsername(username)) {
            mv.addObject("error", "Username already taken!");
            return mv;
        }

        if (usersRepository.existsByEmail(email)) {
            mv.addObject("error", "Email already registered!");
            return mv;
        }

        Users user = new Users();
        user.setUsername(username);
        user.setEmail(email);
        user.setMobile(mobile);
        user.setPassword(password);
        usersRepository.save(user);

        mv.addObject("message", "Signup successful! Please log in.");
        return mv;
    }

    // ✅ Login User (matches login form)
    @RequestMapping("/loginUser")
    public ModelAndView loginUser(@RequestParam String usernameOrEmail,
                                  @RequestParam String password,
                                  HttpSession session) {

        ModelAndView mv = new ModelAndView();

        Users user = usersRepository.findByUsernameOrEmail(usernameOrEmail, usernameOrEmail);

        if (user != null && user.getPassword().equals(password)) {
            // ✅ Store full user object
            session.setAttribute("loggedUser", user);
            mv.setViewName("redirect:/home"); // redirect after login
            return mv;
        } else {
            mv.setViewName("login");
            mv.addObject("error", "Invalid username/email or password!");
            return mv;
        }
    }

    // ✅ Home Page (fixes your 404)
    @RequestMapping("/home")
    public ModelAndView homePage(HttpSession session) {
        Users loggedUser = (Users) session.getAttribute("loggedUser");

        if (loggedUser == null) {
            // user not logged in, redirect to login page
            return new ModelAndView("redirect:/Entertainment");
        }

        ModelAndView mv = new ModelAndView("home");
        mv.addObject("user", loggedUser);
        return mv;
    }

    // ✅ Profile Page
    @RequestMapping("/profile")
    public ModelAndView profilePage(HttpSession session) {
        Users loggedUser = (Users) session.getAttribute("loggedUser");

        if (loggedUser == null) {
            return new ModelAndView("redirect:/Entertainment");
        }

        ModelAndView mv = new ModelAndView("profile");
        mv.addObject("user", loggedUser);
        return mv;
    }

    // ✅ Logout
    @RequestMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/Entertainment";
    }
}
