package com.entertainment.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.view.RedirectView;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.Map;

@Controller
public class SpotifyController {

    @Value("${spotify.client.id}")
    private String clientId;

    @Value("${spotify.client.secret}")
    private String clientSecret;

    @Value("${spotify.redirect.uri}")
    private String redirectUri;

    // Step 1️⃣: Redirect to Spotify Login
    @GetMapping("/loginSpotify")
    public RedirectView loginSpotify() {
        String scope = "user-read-private user-read-email";
        String authUrl = "https://accounts.spotify.com/authorize?client_id=" + clientId
                + "&response_type=code"
                + "&redirect_uri=" + URLEncoder.encode(redirectUri, StandardCharsets.UTF_8)
                + "&scope=" + URLEncoder.encode(scope, StandardCharsets.UTF_8);
        return new RedirectView(authUrl);
    }

    // Step 2️⃣: Spotify Redirects Here with Authorization Code
    @GetMapping("/callback")
    public String callback(@RequestParam("code") String code, HttpSession session) {
        try {
            String tokenUrl = "https://accounts.spotify.com/api/token";

            RestTemplate restTemplate = new RestTemplate();
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

            String auth = clientId + ":" + clientSecret;
            String encodedAuth = Base64.getEncoder().encodeToString(auth.getBytes());
            headers.set("Authorization", "Basic " + encodedAuth);

            Map<String, String> params = new LinkedHashMap<>();
            params.put("grant_type", "authorization_code");
            params.put("code", code);
            params.put("redirect_uri", redirectUri);

            HttpEntity<Map<String, String>> request = new HttpEntity<>(params, headers);

            ResponseEntity<String> response = restTemplate.postForEntity(tokenUrl, request, String.class);

            // ✅ Parse JSON using Jackson
            ObjectMapper mapper = new ObjectMapper();
            Map<String, Object> json = mapper.readValue(response.getBody(), Map.class);
            String accessToken = (String) json.get("access_token");

            // ✅ Save access token in session
            session.setAttribute("spotifyToken", accessToken);
            System.out.println("🎵 Spotify Connected Successfully!");

        } catch (Exception e) {
            e.printStackTrace();
        }
        return "redirect:/addpost"; // go back to addpost.jsp
    }

    // Step 3️⃣: AJAX search endpoint for Spotify songs
    @GetMapping("/spotifySearch")
    @ResponseBody
    public ResponseEntity<?> searchSpotify(@RequestParam("q") String query, HttpSession session) {
        String accessToken = (String) session.getAttribute("spotifyToken");

        if (accessToken == null) {
            return ResponseEntity.status(401).body("Spotify not connected");
        }

        try {
            String searchUrl = "https://api.spotify.com/v1/search?q=" + URLEncoder.encode(query, StandardCharsets.UTF_8)
                    + "&type=track&limit=10";

            RestTemplate restTemplate = new RestTemplate();
            HttpHeaders headers = new HttpHeaders();
            headers.set("Authorization", "Bearer " + accessToken);

            HttpEntity<String> entity = new HttpEntity<>(headers);
            ResponseEntity<String> response = restTemplate.exchange(searchUrl, HttpMethod.GET, entity, String.class);

            return ResponseEntity.ok(response.getBody());
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body("Error while fetching Spotify data");
        }
    }
}
