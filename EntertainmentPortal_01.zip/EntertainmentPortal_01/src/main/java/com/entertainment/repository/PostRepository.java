package com.entertainment.repository;

import com.entertainment.model.Post;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PostRepository extends JpaRepository<Post, Long> {
    // Find all posts by author (optional, useful for profile page)
    List<Post> findByAuthorOrderByCreatedAtDesc(String author);
    List<Post> findAllByOrderByIdDesc();
}
